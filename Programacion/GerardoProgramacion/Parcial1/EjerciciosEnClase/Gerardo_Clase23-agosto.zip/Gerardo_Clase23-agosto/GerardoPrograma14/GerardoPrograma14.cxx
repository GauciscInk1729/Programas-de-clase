//Programa 14
//Mi nombre de mayuscula a minuscula
#include <iostream>

using namespace std;

int main(){
char x1,x2,x3,x4,x5,x6,x7;
cout<<"Este programa cambia mi nombre mayuscula a minuscula\n";
cout<<"\nIntroduce GERARDO\n";
cin>>x1>>x2>>x3>>x4>>x5>>x6>>x7;
cout<<"\nMi nombres en minuscula es:"<<char(x1+32)<<char(x2+32)<<char(x3+32)<<char(x4+32)<<char(x5+32)<<char(x6+32)<<char(x7+32)<<endl;
return 0;
}

