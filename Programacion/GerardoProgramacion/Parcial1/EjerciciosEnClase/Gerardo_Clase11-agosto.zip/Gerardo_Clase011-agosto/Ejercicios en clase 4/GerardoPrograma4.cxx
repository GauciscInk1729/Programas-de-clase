//Programa 4
//Progrma que suma dos numeros
#include<iostream>

using namespace std;

int main(){
    float suma,x,y;
    cout<<"\t\tEste programa suma dos numeros cualesquiera\n";
    cout<<"Introduce el primer numero a sumar: ";
    cin>>x;
    cout<<"Introduce el segundo numero a sumar: ";
    cin>>y;
    suma=x+y;
    cout<<"El resultado de la suma es: "<<suma<<endl;
return 0;
}
