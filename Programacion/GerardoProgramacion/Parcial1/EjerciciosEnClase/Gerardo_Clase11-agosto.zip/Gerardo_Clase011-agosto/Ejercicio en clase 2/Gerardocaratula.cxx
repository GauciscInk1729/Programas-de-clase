//Programa en clase 2
//Caratula
#include <iostream>

using namespace std;


int main(){
cout<<"\t\tUniversidad Autonoma del Estado de Mexico\n\n\t\t\tFacultad de Ciencias\n\n\t\t\tProgramacion\n\n\t\t\tMaestra:Juana Imelda Villareal Valdes\n\n\t\t\tEjercicio 2 en clase\n\n\t\t\tAlumno:Gerardo Gutierrez Alejandre\n\n\t\t";

return 0;
}
