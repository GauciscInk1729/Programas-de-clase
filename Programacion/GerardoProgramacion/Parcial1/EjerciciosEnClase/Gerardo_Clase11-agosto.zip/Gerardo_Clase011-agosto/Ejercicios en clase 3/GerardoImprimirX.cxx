#include <iostream>

using namespace std;

int main(){
    int x=3;
    cout<<"\t\t\tEl valor de x es:\t"<<x<<" o de otra forma:\n";
    cout<<x;
    cout<<"\n\n\n";
return 0;
}
