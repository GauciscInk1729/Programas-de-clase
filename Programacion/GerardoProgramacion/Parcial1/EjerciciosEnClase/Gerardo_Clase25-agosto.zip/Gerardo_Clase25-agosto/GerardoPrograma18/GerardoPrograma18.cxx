//Programa 18
#include <iostream>

using namespace std;

int main(){
    cout<<"Este programa imprime los numeros del 10 al 0";
    for(int i=10;i>=0;i--){
        cout<<endl<<i;
    }
    return 0;
}

