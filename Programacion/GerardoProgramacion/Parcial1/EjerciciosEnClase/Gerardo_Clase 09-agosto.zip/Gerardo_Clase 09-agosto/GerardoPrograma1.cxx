//Programa en clase 1
#include <iostream>// Header that defines the standard input/output stream objects

using namespace std;

int main(){
cout<<"Bienvenido al semestre de clases en linea\n\n";
return 0;
}


