//Programa 30
#include <iostream>
using namespace std;

int main(){
    int i=1;
    cout<<"Programa que escribe mi nombre 5 veces\n";
    cout<<"Usando la instruccion while\n";
    while(i<=5){
        cout<<"Gerardo\n";
        i++;
        }
        cout<<"El ciclo ha terminado";
    return 0;
}
